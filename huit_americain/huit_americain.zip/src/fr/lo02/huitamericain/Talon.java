package fr.lo02.huitamericain;

import java.util.ArrayDeque;

public class Talon extends GroupeCartes{

	public Talon(){
		listeCartes = new ArrayDeque<Carte>();
	}
	
}

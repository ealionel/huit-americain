package fr.lo02.huitamericain;

public enum Evenement {
	inputError,
	posableError,
	piocher,
	carteJouee,
	debutTour,
	finTour,
	afficherCarte,
	vulnerable,
	pasVulnerable,
	carteSucces,
	carteEchec,
	contreCarteSucces,
	contreCarteEchec,
	fin;
}

package fr.lo02.huitamericain;

/**
 * Représente le joueur réel. 
 * 
 *
 */
public class JoueurReel extends Joueur {

	public JoueurReel(String nom){
		super(nom);
	}
	
}

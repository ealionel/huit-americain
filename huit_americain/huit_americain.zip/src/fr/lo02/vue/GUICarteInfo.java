package fr.lo02.vue;

import javax.swing.JPanel;

public class GUICarteInfo extends JPanel {

	
}

package fr.lo02.vue;

public class InterfaceTest {

}

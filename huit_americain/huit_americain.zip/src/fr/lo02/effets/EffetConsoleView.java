package fr.lo02.effets;

import java.util.Observable;
import java.util.Observer;

/**
 * Classe relative à l'affichage des effets durant la partie.
 * @author Lionel EA
 *
 */
public class EffetConsoleView implements Observer{

	public void update(Observable obs, Object o) {
		
	}
}
